package com.blogs.service;

import java.util.List;

import com.blogs.dto.StudentDTO;
import com.blogs.entities.Student;

public interface StudentService 
{
	//add student in student table
	void addStudent(StudentDTO studentDTO);
	
	//get student details by id
    Student getStudentById(Long id);
    
    //get all student details
    List<StudentDTO> getAllStudents();
    
    //update student details
    void updateStudent(StudentDTO studentDTO);
    
    //delete student detail by id
    void deleteStudent(Long id);

}
