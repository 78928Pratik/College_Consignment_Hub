package com.blogs.entities;

public enum Status 
{
	
	AVAILABLE,SOLD;

}
