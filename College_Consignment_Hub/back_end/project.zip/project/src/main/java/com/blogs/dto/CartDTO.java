package com.blogs.dto;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter

public class CartDTO 
{
	private Long cart_id;
	private Long seller_id;
	
	

}
